# Bootstrap 5 admin subtheme theme

[Bootstrap 5 admin](https://www.drupal.org/project/bootstrap5_admin) subtheme.

## Development.

### CSS compilation.

Prerequisites: install [sass](https://sass-lang.com/install).

To compile, run from subtheme directory: `sass scss/style.scss css/style.css`

Or: `sass scss:css`
