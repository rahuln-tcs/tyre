(function($, Drupal) {
    'use strict';
  
    Drupal.behaviors.tyre_admin = {
      attach: function(context, settings) {
        var code_type = $('#edit-field-serial-number').find("option:selected").text();
        $('#edit-field-serial-number, #edit-field-rm-serial-number', context).change(function() {
          code_type = $(this).find("option:selected").text();
          $('.tyre-title input').val(code_type);
        });
      }
    }
  })(jQuery, Drupal);