<?php

namespace Drupal\tyre_management\services;

use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Class Tyres.
 *
 * @package Drupal\tyre_management
 */
class Tyres {

  /**
   * Database connection object.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $connection;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

/**
   * Common service constructor.
   *
   * @param \Drupal\Core\Database\Connection $connection
   *   The Database service.
   * @param \Symfony\Component\HttpFoundation\RequestStack $requestStack
   *   Managing Request URL information.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param Drupal\Core\Utility\LinkGenerator $link_generator
   *   The link generator service.
   * @param Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   The cache backend service.
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   The language manager.
   */
  public function __construct(
    Connection $connection,
    EntityTypeManagerInterface $entity_type_manager
    ) {
    $this->connection = $connection;
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * Get the Inward tyres entry.
   *
   * @param bool $status
   *   Tyre current status.
   *
   * @return array
   *   get tyres entries.
   */
  public function getInwardTyres($status = TRUE) {
    $index = $this->entityTypeManager->getStorage('search_api_index')->load('categories');
    $query = $index->getQuery()
    ->accessCheck(TRUE);
       $query->addCondition('status', 1)
      ->addCondition('title', $filtercodes, "IN");
    $categories = $query->execute();
  }

  /**
   * Check tyre fitment availablity.
   *
   * @param bool $serial_number
   *   Tyre serial_number.
   *
   * @return bool
   *   get tyres entries.
   */
  public function isAvailableForFitment($serial_number) {
    $index = $this->entityTypeManager->getStorage('node');
    $query = $index->getQuery();
    $query->Condition('status', 1)
      ->Condition('type', 'tyre_fitment')
      ->Condition('field_serial_number', $serial_number)
      ->Condition('field_tyre_fitment_status', 1)
      ->accessCheck(TRUE);
    $result = $query->execute();
    $status = empty($result) ? FALSE : TRUE;
    if ($status) {
      $query = $index->getQuery();
      $query->Condition('status', 1)
        ->Condition('type', 'tyre_removal')
        ->Condition('field_rm_serial_number', $serial_number)
        ->Condition('field_tyre_removal_status', 1)
        ->accessCheck(TRUE);
      $result = $query->execute();
      $status = empty($result) ? TRUE : FALSE;
    }
    return $status;
  }

/**
   * Update status.
   *
   * @param bool $serial_number
   *   Tyre serial_number.
   * @param bool $type
   *   Tyre status type.
   * 
   * @return bool
   *   get tyres entries.
   */
  public function updateTyreStatus($serial_number, $type) {
    if ($type == "tyre_fitment") {
      $index = $this->entityTypeManager->getStorage('node');
      $query = $index->getQuery();
      $query->Condition('status', 1)
        ->Condition('type', 'tyre_fitment')
        ->Condition('field_serial_number', $serial_number)
        ->Condition('field_tyre_fitment_status', 1)
        ->accessCheck(TRUE);
      $nids = $query->execute();
      if (!empty($nids)) {
        foreach ($nids as $nid) {
          $fitmentnode = $this->entityTypeManager->getStorage('node')->load($nid);
          $fitmentnode->set('field_tyre_fitment_status', 0);
          $fitmentnode->save();
        }
      }
    }
    if ($type == "tyre_removal") {
      $index = $this->entityTypeManager->getStorage('node');
      $query = $index->getQuery();
      $query->Condition('status', 1)
        ->Condition('type', 'tyre_removal')
        ->Condition('field_rm_serial_number', $serial_number)
        ->Condition('field_tyre_removal_status', 1)
        ->accessCheck(TRUE);
      $nids = $query->execute();
      if (!empty($nids)) {
        foreach ($nids as $nid) {
          $fitmentnode = $this->entityTypeManager->getStorage('node')->load($nid);
          $fitmentnode->set('field_tyre_removal_status', 0);
          $fitmentnode->save();
        }
      }
    }
  }
}